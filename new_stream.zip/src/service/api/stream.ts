export const fetchStreamUrl = async () => {
    try {
        
    } catch (error) {
        
    }
}