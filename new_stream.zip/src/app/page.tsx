'use client'
import Frames from "@/components/Frames";
import { useStream, VideoStates } from "@/hooks/useStream";
import moment from "moment";
import Image from "next/image";
import { use, useCallback, useEffect, useRef, useState } from "react";

export default function Home() {
  // Clear queue handler
  function handleClearQueue() {
    if (videoRef.current) {
      videoRef.current.removeAttribute("src");
      videoRef.current.load();
    }
    startTimeRef.current = 0;
    metaDataRef.current = [];
    setFrameIfo(null);
  }
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isForward, setIsForward] = useState<boolean>(true);
  const [option, setOption] = useState({
    siteId: 1,
    channelId: 18,
    timestamp: 0,
  });
  const [frameInfo, setFrameIfo] = useState<any>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const { start, stop, pause, resume, setVideoStates, metaDataRef, startTimeRef, videoStates } = useStream(videoRef);

  // Modularized Handlers
  const handleStart = useCallback(() => {
    start(option);
  }, [option, start, stop]);

  const handleStop = useCallback(() => {
    stop();
  }, [stop]);

  function handleOptionChange(e: React.ChangeEvent<HTMLInputElement>) {
    const { name, value } = e.target;
    setOption((prev) => ({
      ...prev,
      [name]: value ? Number(value) : 0,
    }));
  }

  function moveFrame(forward: boolean) {
    if (videoRef.current) {
      videoRef.current.currentTime += forward ? 1 / 10 : -1 / 10;
    }
  }

  const handleNextFrame = useCallback(() => moveFrame(true), [videoStates.playbackRate]);
  const handlePrevFrame = useCallback(() => moveFrame(false), [videoStates.playbackRate]);

  const handle2sCut = useCallback(() => {
    const video = videoRef.current;
    if (video){
      video.currentTime += 2;
    }
  }, [])

  function updateFrameMeta(now: DOMHighResTimeStamp, meta: VideoFrameCallbackMetadata) {
    console.log("$$$$$===== buffer length ", metaDataRef.current.length)
    const currentVideoTime = Math.ceil(meta.mediaTime * 1000);
    const currentPlayTime = startTimeRef.current + currentVideoTime;
    const metaData = metaDataRef.current.reduce((nearest, item, index) => {
      return Math.abs(item.timeStamp - currentPlayTime) > Math.abs(nearest.timeStamp - currentPlayTime) ? nearest : {...item, index};
    }, {...(metaDataRef.current[0] || {}), index: 0});
    setFrameIfo(metaData);
    const diff = metaData.timeStamp - currentPlayTime;
    if (diff > 100){
      console.log("$$$$$===== meta diff: ", diff)
    }
    videoRef.current?.requestVideoFrameCallback(updateFrameMeta);
    if (metaData)
      metaDataRef.current = metaDataRef.current.slice(Math.max(0, (metaData.index || 0) - 50));
  }

  function handleOnLoad() {
    const video = videoRef.current;
    if (video) {
      video.requestVideoFrameCallback(updateFrameMeta);
      video.playbackRate = videoStates.playbackRate;
    }
  }

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = videoStates.playbackRate;
    }
  }, [videoStates.playbackRate]);

  useEffect(() => {
    let intervalId: any = null;
    function reversePlay() {
      if (videoRef.current && videoRef.current.currentTime > 0)
        videoRef.current.currentTime -= 1 / 10;
      else {
        clearInterval(intervalId);
        intervalId = null;
        setIsForward(true);
      }
    }
    if (videoRef.current && !isForward) {
      videoRef.current.pause();
      setVideoStates({...videoStates, isPlaying: false});
      intervalId = setInterval(reversePlay, 1000 / (10 * videoStates.playbackRate));
    } else {
      if (videoRef.current) {
        videoRef.current.play();
        setVideoStates({...videoStates, isPlaying: true});
      }
    }
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
    };
  }, [isForward, videoStates.playbackRate]);

  useEffect(() => {
    handleStop();
  }, [handleStop])

  return (
    <div className="flex flex-col items-center justify-center h-screen w-screen bg-gray-100">
      <div className="w-1/2 h-1/2 bg-slate-400 relative">
        <div className={`absolute flex flex-row items-center gap-2 ms-2 mt-2 bg-white px-2 rounded z-50 ${videoStates.isLive ? "" : "cursor-pointer"}`} onClick={() => alert("ok")}>
          <div className={`w-1.5 h-1.5 rounded-full animate-ping ${videoStates.isLive ? 'bg-green-700' : "bg-red-600"}`}/>
          <p className="text-sm">{videoStates.isLive ? "Live" : "Go Live"}</p>
        </div>
        <Frames frameInfo={frameInfo} isEvent={false} svgRef={svgRef} videoRef={videoRef} />
        <video ref={videoRef} className="absolute top-0 right-0 bottom-0 left-0 object-contain h-full w-full" autoPlay muted onLoadedData={handleOnLoad} />
      </div>
      <div>
        <p>{moment(frameInfo?.timeStamp).format("YYYY-MM-DD HH:mm:ss")}</p>
      </div>
      <div className="mt-4 flex flex-row w-1/2">
        <div className="w-1/2 bg-green-200 flex-1/2 flex flex-col align-middle p-2">
          <label htmlFor="videoStates.playbackRate" className="mr-2">Playback Rate :</label>
          <select name="videoStates.playbackRate" id="videoStates.playbackRate" value={videoStates.playbackRate} onChange={(e) => {setVideoStates({ ...videoStates, playbackRate: Number(e.target.value) })}}>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="4">4</option>
            <option value="8">8</option>
          </select>
          <div className="flex flex-row align-middle gap-4 justify-center mt-3">
            <button className="bg-fuchsia-500 w-10 cursor-pointer" onClick={handlePrevFrame}>&#x23EE;</button>
            <button className="bg-fuchsia-500 w-10 cursor-pointer" onClick={handleNextFrame}>&#x23ED;</button>
          </div>
          <div className="flex flex-row align-middle gap-4 justify-center mt-3">
            {
              videoStates.isPlaying ? (
                <button className="bg-amber-500 w-10 cursor-pointer" onClick={() => {videoRef.current?.pause(); setVideoStates({...videoStates, isPlaying: false});}}>&#x23F8;</button>
              ) : (
                <button className="bg-green-500 w-10 cursor-pointer" onClick={() => {videoRef.current?.play(); setVideoStates({...videoStates, isPlaying: true});}}>&#9654;</button>
              )
            }
          </div>
          <div className="flex flex-row align-middle gap-4 justify-center mt-3">
            {
              isForward ? (
                <button className=" w-10 cursor-pointer" onClick={() => {setIsForward(false);}}>&#x23EA;</button>
              ) : (
                <button className=" w-10 cursor-pointer" onClick={() => {setIsForward(true);}}>&#x23E9;</button>
              )
            }
          </div>
          <div className="text-center mt-2">
            <button className="bg-red-300 w-24 cursor-pointer" onClick={handleClearQueue}>Clear Queue</button>
            <button className="bg-red-300 w-24 cursor-pointer" onClick={handle2sCut}>Cut 2s</button>
          </div>
        </div>
        <div className="w-1/2 bg-blue-200 flex-1/2 flex flex-col align-middle p-2">
          <label htmlFor="site">Site:</label>
          <input type="number" name="siteId" id="" value={option.siteId} className="ring-1" onChange={handleOptionChange} />
          <label htmlFor="channel">Channel:</label>
          <input type="number" name="channelId" id="" value={option.channelId} className="ring-1" onChange={handleOptionChange} />
          <label htmlFor="channel">Timestamp:</label>
          <input type="number" name="timestamp" id="" value={option.timestamp} className="ring-1" onChange={handleOptionChange} />
          <button className="bg-sky-400 mt-2 cursor-pointer" onClick={handleStart}>Start</button>
          <button className="bg-slate-400 mt-2 cursor-pointer" onClick={handleStop}>Stop</button>
        </div>
      </div>
    </div>
  );
}
