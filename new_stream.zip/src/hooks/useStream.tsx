import { useRef, useCallback, useEffect, RefObject, useState, useMemo } from "react";
import { v4 as uuidv4 } from "uuid";

type UseStreamReturn = {
  start: (option: ConnOption) => void;
  stop: () => void;
  pause: () => void;
  resume: () => void;
  setVideoStates: (a: VideoStates) => void;
  startTimeRef: RefObject<number>;
  metaDataRef: RefObject<FrameMetaData[]>;
  videoStates: VideoStates;
};

type Direction = "forward" | "backward";

interface ConnOption {
  siteId: number;
  channelId: number;
  timestamp?: number;
  jobId?: string;
  eventId?: string;
}

interface ObjectInfo {
  x: number;
  y: number;
  w: number;
  h: number;
  t: number;
  c: number;
  i: number;
  e: boolean;
}

interface FrameMetaData {
  channelId: number;
  frameId: number;
  objectList: ObjectInfo[];
  peopleCount: number;
  refHeight: number;
  refWidth: number;
  siteId: number;
  timeStamp: number;
  timeStampEncoded: number;
  timeStampEnd: number;
  vehicleCount: number;
  index?: number;
}

export interface VideoStates {
  isLive: boolean;
  isPlaying: boolean;
  direction: Direction;
  playbackRate: number;
  isFrameByFrame: boolean;
}

const initVideoState = {
  isLive: false,
  isPlaying: true,
  direction: 'forward' as Direction,
  playbackRate: 1,
  isFrameByFrame: false,
}

export function useStream(videoRef: RefObject<HTMLVideoElement | null>): UseStreamReturn {
  // Queue for incoming video frames
  const frameQueueRef = useRef<Array<BufferSource>>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const mediaSourceRef = useRef<MediaSource | null>(null);
  const sourceBufferRef = useRef<SourceBuffer | null>(null);
  const sourceOpenHandlerRef = useRef<((this: MediaSource, ev: Event) => any) | null>(null);
  const startTimeRef = useRef<number>(0);
  const metaDataRef = useRef<FrameMetaData[]>([]);
  const heartBeatIntervalIdRef = useRef<ReturnType<typeof setInterval>>(null);
  const commandIdRef = useRef<string | null>(null);
  const sessionId = useMemo(() => uuidv4(), []);
  const [videoStates, setVideoStates] = useState<VideoStates>(initVideoState);
  const videoStateRef = useRef<VideoStates>(initVideoState);

  const app = 0;
  const stream = 0;
  const cloudIp = "<videoneticsAddr>";

  useEffect(() => {
    videoStateRef.current = videoStates;
  }, [videoStates])

  function genCommandId() {
    commandIdRef.current = uuidv4();
    return commandIdRef.current;
  }

  function pause() {
    const payload = {
      "type": "command",
      "value": "pause",
      "id": genCommandId(),
    }

    wsRef.current && wsRef.current.send(JSON.stringify(payload));
  }

  function resume() {
    const payload = {
      "type": "command",
      "value": "resume",
      "id": genCommandId(),
    }

    wsRef.current && wsRef.current.send(JSON.stringify(payload));
  }

  function monitorBuffUsage(maxBufferDuration: number) {
    const buffered = sourceBufferRef.current?.buffered;
    if (buffered && buffered.length > 0) {
      const start = buffered.start(0);
      const end = buffered.end(buffered.length - 1);
      const bufferedDuration = end - start;

      if (bufferedDuration > maxBufferDuration && sourceBufferRef.current && !sourceBufferRef.current.updating) {
        try {
          sourceBufferRef.current.remove(start, end - maxBufferDuration / 2);
        } catch (error) {
          // console.error("$$$$==== Failed to remove used buffer");
        }
      }
    }
  }

  function seekVideoToCurrentTime() {
    try {
      const video = videoRef.current;
      const buffered = sourceBufferRef.current?.buffered;
      if (video && buffered && buffered.length > 0) {
        const end = buffered.end(buffered.length - 1);
        const currentTime = video.currentTime;
        if (currentTime && end > currentTime && end - currentTime >= 3.0) {
          // console.log("$$$$$=====seek log: ", end, currentTime)
          video.currentTime = end; 
        }
      }
    } catch (error) {}
  };

  function cleanupWebSocket() {
    if (wsRef.current) {
      wsRef.current.close();
      // wsRef.current will be set to null in the onclose handler
    }
  }

  function cleanupVideo() {
    if (videoRef.current) {
      videoRef.current.removeAttribute("src");
      videoRef.current.load();
    }
  }

  function cleanupMediaSource() {
    if (mediaSourceRef.current) {
      if (sourceOpenHandlerRef.current) {
        mediaSourceRef.current.removeEventListener(
          "sourceopen",
          sourceOpenHandlerRef.current
        );
        sourceOpenHandlerRef.current = null;
      }
      mediaSourceRef.current = null;
    }
  }

  function cleanupSourceBuffer() {
    if (sourceBufferRef.current) {
      sourceBufferRef.current = null;
    }
  }

  function cleanupRefs() {
    frameQueueRef.current = [];
    startTimeRef.current = 0;
    metaDataRef.current = [];
  }

  // stop heart bit interval
  const stopHeartBit = () => {
    if (heartBeatIntervalIdRef.current){
      clearInterval(heartBeatIntervalIdRef.current)
      heartBeatIntervalIdRef.current = null;
    }
  }

  // send socket heart bit on 30 sec of interval
  const sendHeartBit = (ws: WebSocket) => {
    stopHeartBit();
    const payload = {"type": "heartBit", "sessionId": sessionId}
    heartBeatIntervalIdRef.current = setInterval(() => ws?.send(JSON.stringify(payload)), 30000);
  }

  // handle resume pause
  let count = 0;
  let readyForLoad = false;

  const maintainAutoPause = () => {
    if (count === (5 * videoStateRef.current.playbackRate)) {
      pause();
      readyForLoad = true;
    };
    count <= (5 * videoStateRef.current.playbackRate) && count++;
  }

  const maintainAutoResume = () => {
    readyForLoad = false;
    count = 0;
    resume();
  }

  // create connection string
  const prepareConnectionString = useCallback((option: ConnOption) => {
    // const BASE_STREAM_URL = "ws://172.16.1.16:8083";
    // const BASE_STREAM_URL = "wss://vsaasstreaming1.videonetics.com";
    const BASE_STREAM_URL = "ws://172.16.2.143:8083";
    // const BASE_STREAM_URL = "ws://172.16.1.144:8083";
    // const BASE_STREAM_URL = "ws://127.0.0.1:8083";
    let isLive = 1;
    const { siteId, channelId, timestamp, jobId, eventId } = option;

    if (timestamp && timestamp > 0) {
      isLive = 0;
    }

    let name =
      siteId +
      "/" +
      channelId +
      "/" +
      app +
      "/" +
      isLive +
      "/" +
      stream +
      "/" +
      timestamp +
      "/" +
      sessionId;

    if (jobId && eventId) {
      name = name + "/" + jobId + "/" + eventId;
    }

    const src = "videonetics://" + cloudIp + "/" + name;
    let wsUrl =
      "/api/ws?name=" +
      encodeURIComponent(name) +
      "&src=" +
      encodeURIComponent(src);

    wsUrl = `${BASE_STREAM_URL}` + wsUrl;
    return wsUrl;
  }, []);

  // handle start function
  const start = useCallback(
    (option: ConnOption) => {
      stop();
      startTimeRef.current = 0;
      metaDataRef.current = [];
      const connectionString = prepareConnectionString(option);
      // if (wsRef.current) return; // Already started
      const mediaSource = new MediaSource();
      mediaSourceRef.current = mediaSource;
      if (videoRef.current) {
        videoRef.current.src = URL.createObjectURL(mediaSource);
      }

      let codec: string | null = null;
      let sourceBuffer: SourceBuffer | null = null;

      function processQueue() {
        if (!sourceBuffer || sourceBuffer.updating) return;
        const nextFrame = frameQueueRef.current.shift();
        if (nextFrame) {
          if (nextFrame instanceof Blob) {
            nextFrame.arrayBuffer().then((arrayBuffer) => {
              if (sourceBuffer) {
                try {
                  sourceBuffer.appendBuffer(arrayBuffer);
                } catch (err) {
                  console.log("$$$$$ Error appending buffer:", err);
                }
              }
            });
          } else {
            if (sourceBuffer) {
              try {
                sourceBuffer.appendBuffer(nextFrame);
              } catch (err) {
                console.log("$$$$$ Error appending buffer:", err);
              }
            }
          }
        }
      }

      function cleanupBuffer() {
        if (!sourceBuffer || !videoRef.current) return;
        const currentTime = videoRef.current.currentTime;
        const removeBefore = Math.max(0, currentTime - 5);
        try {
          if (!sourceBuffer.updating && sourceBuffer.buffered.length > 0) {
            const end = sourceBuffer.buffered.end(0);
            if (end > removeBefore) {
              sourceBuffer.remove(0, removeBefore);
              console.log("$$$$$===== buffer removed", end, removeBefore)
            }
          }
        } catch (err) {
          // Ignore errors from remove
        }
      }

      mediaSource.addEventListener("sourceopen", () => {
        // Wait for codec info from WebSocket before creating SourceBuffer
      });

      wsRef.current = new WebSocket(connectionString);
      wsRef.current.binaryType = "arraybuffer";

      wsRef.current.onopen = () => {
        wsRef.current?.send(JSON.stringify({ type: "mse", value: "" }));
        wsRef.current && sendHeartBit(wsRef.current);
      };

      wsRef.current.onmessage = (event) => {
        if (!event.data || typeof event.data === "string") {
          const message = event.data as string;
          const data: any = JSON.parse(message);
          if (data.type === "mse" && typeof data.value === "string" && !codec) {
            codec = data.value;
            if (mediaSource.readyState === "open" && typeof codec === "string") {
              try {
                sourceBuffer = mediaSource.addSourceBuffer(codec);
                sourceBufferRef.current = sourceBuffer;
                sourceBuffer.addEventListener("updateend", () => {
                  processQueue();
                  // cleanupBuffer();
                  videoStateRef.current.isLive && seekVideoToCurrentTime();
                  monitorBuffUsage(videoStateRef.current.isLive ? 10 : 60);
                });
              } catch (err) {
                console.log("Error creating SourceBuffer with codec:", codec, err);
              }
            }
            return;
          } else if (data instanceof Array) {
            (!!!startTimeRef.current) && (startTimeRef.current = data[0].timeStamp);
            metaDataRef.current = [...metaDataRef.current, ...data];
            // if (metaDataRef.current.length > 50){
            //   metaDataRef.current = metaDataRef.current.slice(-50);
            // }
            // data.map(element => console.log("$$$$$=====", element.timeStamp))
          }
          return;
        }
        if (!sourceBuffer) return;
        if (event.data instanceof ArrayBuffer) {
          maintainAutoPause();
          frameQueueRef.current.push(event.data);
          processQueue();
          return;
        } else if (event.data instanceof Uint8Array) {
          maintainAutoPause();
          frameQueueRef.current.push(event.data.slice().buffer);
          processQueue();
          return;
        } else if (event.data instanceof Blob) {
          maintainAutoPause();
          event.data.arrayBuffer().then((arrayBuffer) => {
            frameQueueRef.current.push(arrayBuffer);
            processQueue();
            return;
          });
        }
      };

      wsRef.current.onclose = function () {
        if (wsRef.current === this) {
          wsRef.current = null;
          stopHeartBit();
          console.log("WebSocket connection closed");
        }
      };
    },
    [prepareConnectionString]
  );

  // handle stop functionality
  const stop = useCallback(() => {
    cleanupWebSocket();
    cleanupVideo();
    cleanupMediaSource();
    cleanupSourceBuffer();
    cleanupRefs();
  }, []);

  // video time update listener callback
  const videoTimeUpdateCallback = useCallback(() => {
    count--;
    if (readyForLoad){
      const video = videoRef.current;
      const sourceBuffer = sourceBufferRef.current;
      if (video && sourceBuffer && sourceBuffer.buffered){
        const currentTime = video.currentTime;
        const endTime = sourceBuffer.buffered.end(sourceBuffer.buffered.length - 1);
        const diff = endTime - currentTime;
        console.log("$$$$$===== resume call: ", sourceBuffer?.buffered, diff)
        if (diff <= (2 * videoStateRef.current.playbackRate)){
          maintainAutoResume();
        }
      } else {

      }
    }
  }, [])

  // stop connection on unmount
  useEffect(() => {
    return () => {
      stop();
    };
  }, [stop]);

  // set time update event listener on archive play
  useEffect(() => {
    const video = videoRef.current;
    if (video){
      video.addEventListener("timeupdate", videoTimeUpdateCallback);
    }

    return () => {
      video?.removeEventListener("timeupdate", videoTimeUpdateCallback);
    }
  }, [videoStates.isLive, videoTimeUpdateCallback])

  return { start, stop, pause, resume, setVideoStates, startTimeRef, metaDataRef, videoStates};
}
